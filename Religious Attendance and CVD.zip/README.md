# Religious_Attendance_CVD

This is a repository containing the data preprocessing, visualization, and modeling of CVD likelihood based on demographics, social determinants of health, and various risk factors. 

- Data: Data provided by NHANES 2007/2008 
- R: Relevant R code and html notebooks
